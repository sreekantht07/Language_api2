$('input[name="errortick"]').click(function() {
    $('.report_error').toggle(this.checked);
});